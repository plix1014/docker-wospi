# script to start the WOSPi software using gnu screen
# screen name: wxscreen

#!/bin/bash

screen -m -d -S wxscreen /usr/bin/python /home/wospi/wetter/wospi.pyc


