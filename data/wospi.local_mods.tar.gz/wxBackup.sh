#!/bin/bash
#-------------------------------------------------------------------------------
# Name:        wxBackup.sh
# Purpose:     creates backup of WOSPi, extended for my needs
#
#   http://www.annoyingdesigns.com  -  http://www.bitwrap.no
#
# Author:      Torkel M. Jodalen <tmj@bitwrap.no>
#
# Changed:     Peter Lidauer <plix1014@gmail.com>
#
# Created:     26.03.2014
# Copyright:   (c) Torkel M. Jordalen, Peter Lidauer 2014
# Licence:     CC BY-NC-SA http://creativecommons.org/licenses/by-nc-sa/4.0/
#-------------------------------------------------------------------------------

WOSPI_HOME=/home/wospi/wetter
BK_DIR=/home/wospi/backup
DATE=$(date +'%Y%m%d_%H')
YYMM=$(date +'%Y-%m')

SQL=/usr/bin/sqlite3

ALTERNATE_BK_SERVER=192.168.20.254

# possible values:
# ftp|lftp
MODE=ftp

# possible values:
# yes|no
BACKUP_BY_MAIL=no

SOURCEDATA=$(grep ^CSVPATH $WOSPI_HOME/config.py \
    | awk -F"=" '{print $2}' \
    | sed -e 's, ,,g' -e "s,',,g")

SCP_T=$(grep ^SCPTARGET $WOSPI_HOME/config.py \
    | awk -F"=" '{print $2}' \
    | sed -e 's, ,,g' -e "s,',,g")

TMPDIR=$(grep ^TMPPATH $WOSPI_HOME/config.py \
    | awk -F"=" '{print $2}' \
    | sed -e 's, ,,g' -e "s,',,g")

LOCAL_TMP_DIR=$(grep ^LOCAL_TMP_DIR $WOSPI_HOME/config.py \
    | awk -F"=" '{print $2}' \
    | sed -e 's, ,,g' -e "s,',,g" \
    | sed -e 's,TMPPATH,$TMPDIR,g' \
    | tr '+' '/')


ZIPDATA_FULL=$TMPDIR/wxdata.zip
ZIPDATA_INC=$TMPDIR/wxdata-$YYMM.zip

MAILTO=peter@localhost

DEBUG=

#-----------------------------------------------------------------------------------

if [ $# -ne 1 ]; then
    echo "usage: $0 <full|inc>"
    exit 1
fi

if [ "$1" = "inc" ]; then
    ZIPDATA=$ZIPDATA_INC
    LEV="${YYMM}*"
    if [ $(date +'%d') -eq 1 ]; then
	LAST=$(echo "select strftime('%Y-%m',date('now','start of month','+0 month','-1 day'));" | $SQL)
        ZIPDATA_INC_LAST=$TMPDIR/wxdata-$LAST.zip
    fi
else
    ZIPDATA=$ZIPDATA_FULL
    ZIPDATA_INC_LAST=
    LEV="*"
fi

echo "$(date +'%a %b %d %T %Y LT:') Backup $ZIPDATA"
zip -q $ZIPDATA ${SOURCEDATA}${LEV}
EL=$?

if [ -n "$ZIPDATA_INC_LAST" ]; then
    echo "$(date +'%a %b %d %T %Y LT:') Backup $ZIPDATA_INC_LAST"
    zip -q $ZIPDATA_INC_LAST ${SOURCEDATA}${LAST}*
fi

if [ $EL -eq 0 ]; then
    MSG="Please find a backup archive of WOSPi weather observations attached." 
else
    MSG="ERROR creating $ZIPDATA..."
fi


# mail backup
if [ "$BACKUP_BY_MAIL" = "yes" ]; then
    echo "$MSG" | mutt $MAILTO  -s "WOSPi weather data - BACKUP" -a $ZIPDATA
    echo "$MSG"
else

    EL1=0
    if [ "$1" != "inc" ]; then
	# backup to remote host

	SCP_HOST=$(echo $SCP_T | awk -F":" '{print $1}' | sed -e 's,.*@,,g')
	SCP_HOST_USER=$(echo $SCP_T | awk -F":" '{print $1}')
	TRANSFER_STRING=${SCP_HOST_USER}:${LOCAL_TMP_DIR}

	TRANSFER_STRING=$(echo $TRANSFER_STRING)

	if [ $DEBUG ]; then
	    echo "SCP_T: $SCP_T"
	    echo "SCP_HOST: $SCP_HOST"
	    echo "LOCAL_TMP_DIR: $LOCAL_TMP_DIR"
	    echo "TRANSFER_STRING: $TRANSFER_STRING"
	fi

	if [ "$SCP_HOST" != "$(uname -n)" ]; then
	    ping -c 1 $SCP_HOST >/dev/null 2>&1
	    EL1=$?
	    if [ $EL1 -eq 0 ]; then
		echo "$(date +'%a %b %d %T %Y LT:') saving $ZIPDATA at $TRANSFER_STRING"
		scp -B $ZIPDATA $TRANSFER_STRING
	        EL1=$?
	    else
		# backup to local host
		echo "$(date +'%a %b %d %T %Y LT:') $SCP_HOST down. backing up locally to $BK_DIR."
		cp $ZIPDATA $BK_DIR
	        EL1=$?
	    fi

	else
	    # backup to local host
	    echo "$(date +'%a %b %d %T %Y LT:') Backing up locally to $BK_DIR."
	    cp $ZIPDATA $BK_DIR
	    EL1=$?
	fi
    fi
    EL=$(( EL + EL1 ))

    ping -c 2 $ALTERNATE_BK_SERVER >/dev/null 2>&1
    if [ $? -eq 0 ]; then
	echo "$(date +'%a %b %d %T %Y LT:') saving $ZIPDATA at $ALTERNATE_BK_SERVER"
	BN=${ZIPDATA##*/}
	cd ${ZIPDATA%/*}
	$MODE $ALTERNATE_BK_SERVER <<-EOF
		put $BN
		bye
		quit
		EOF
	EL1=$?
	EL=$(( EL + EL1 ))
	if [ -n "$ZIPDATA_INC_LAST" ]; then
	    echo "$(date +'%a %b %d %T %Y LT:') saving $ZIPDATA_INC_LAST at $ALTERNATE_BK_SERVER"
	    BN=${ZIPDATA_INC_LAST##*/}
	    cd ${ZIPDATA_INC_LAST%/*}
	    $MODE $ALTERNATE_BK_SERVER <<-EOF
		put $BN
		bye
		quit
		EOF
	fi
    else
	echo "$(date +'%a %b %d %T %Y LT:') $ALTERNATE_BK_SERVER seems to be down."
    fi
fi


if [ $EL -eq 0 ]; then
    echo "$(date +'%a %b %d %T %Y LT:') Backup finished."
    [ -f "$ZIPDATA" ] && rm -f "$ZIPDATA"
    [ -f "$ZIPDATA_INC_LAST" ] && rm -f "$ZIPDATA_INC_LAST"
else
    echo "$(date +'%a %b %d %T %Y LT:') Backup failed"
fi

